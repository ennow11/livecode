var input = ['Steve Fox']

function changeSpacesWith (input) {
  return input;
}
var splice = input.splice(0,1);
var splice = input.splice(1,1, 'Steve - Fox');

console.log(input);

var input = ['Sergei Dragunov']

function changeSpacesWith (input) {
  return input;
}
var splice = input.splice(0,1);
var splice = input.splice(1,1, 'Sergei + Dragunov');

console.log(input);