var name = "rinnina"
if (name[0]== 'a' || name[0]=='b' || name[0]=='c' || name[0]=='d') {
  console.log('masuk group pertama')
}
else{
  if (name[0]== 'e' || name[0]=='f' || name[0]=='g' || name[0]=='h'){
    console.log('masuk gropu kedua')
  }
  else {
    console.log('masuk group terakhir')
}
}