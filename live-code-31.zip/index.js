function addTitle (person1, person2, person3, person4) {
  var a = ' Mr.';
    console.log(a + person1 + ',' + a + person2 + ',' + a + person3 + ',' + a + person4)
  }
  
  addTitle("Stave Fox", "Jin Kazama", 'Eddie Gordo', 'Geese Howard');
